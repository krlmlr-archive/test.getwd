context("getwd")

message("In test: ", getwd())
