library(testthat)
library(test.getwd)

test_check("test.getwd")
